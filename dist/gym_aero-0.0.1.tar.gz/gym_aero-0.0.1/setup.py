from setuptools import setup

setup(name='gym_aero',
      version='0.0.1',
      author='RMIT UAS Research Team',
      install_requires=['gym']
)  
