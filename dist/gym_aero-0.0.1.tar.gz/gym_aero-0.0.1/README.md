# Gym Quad

This package contains the Gym Quad environments for training flight controllers for the given tasks using reinforcement learning.
