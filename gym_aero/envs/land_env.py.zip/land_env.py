import simulation.quadrotor3 as quad
import simulation.config as cfg
import simulation.animation as ani
import matplotlib.pyplot as pl
import mpl_toolkits.mplot3d.art3d as art3d
import numpy as np
import random
from math import pi, sin, cos
import gym
from gym import error, spaces, utils
from gym.utils import seeding

class LandEnv(gym.Env):
    """
        Environment wrapper for training low-level flying skills. In this environment, the aircraft
        has a deterministic starting state by default. We can switch it to have non-deterministic
        initial states. This is obviously much harder.
    """
    def __init__(self):
        metadata = {'render.modes': ['human']}

        # environment parameters

        self.goal_xyz = np.array([[random.uniform(-3,3)],
                                [random.uniform(-3,3)],
                                [random.uniform(-3,0)]])
        self.spawn = np.array([[random.uniform(-3,3)],
                                [random.uniform(-3,3)],
                                [random.uniform(0,3)]])
        self.t = 0
        self.T = 2.5
        self.r = 1.5
        self.action_space = np.zeros((4,))
        self.observation_space = np.zeros((23,)) ##Nomal is 22

        # simulation parameters
        self.params = cfg.params
        self.iris = quad.Quadrotor(self.params)
        self.ctrl_dt = 0.05
        self.sim_dt = self.params["dt"]
        self.steps = range(int(self.ctrl_dt/self.sim_dt))
        self.hov_rpm = self.iris.hov_rpm
        self.trim = [self.hov_rpm, self.hov_rpm,self.hov_rpm, self.hov_rpm]
        self.action_bound = [0, self.iris.max_rpm]
        self.H = int(self.T/self.ctrl_dt)
        self.hov_rpm = self.iris.hov_rpm
        self.trim = [self.hov_rpm, self.hov_rpm,self.hov_rpm, self.hov_rpm]
        self.trim_np = np.array(self.trim)
        self.bandwidth = 35.

        self.fig = None
        self.axis3d = None
        self.v = None

        # define bounds here
        self.xzy_bound = 0.5
        self.zeta_bound = pi/3
        self.uvw_bound = 0.5
        self.pqr_bound = 0.25


        xyz, _, _, _ = self.iris.get_state()
        self.vec = xyz-self.goal_xyz
        #print(self.vec)
        self.dist_norm = np.linalg.norm(self.vec)
        self.landing_angle =(180/np.pi)* np.arcsin((xyz[2] - self.goal_xyz[2])/self.dist_norm)[0]




    def reward(self, state, action):
        xyz, zeta, _, pqr = state

        curr_dist = xyz-self.goal_xyz
        self.vec = curr_dist
        ##magnitude of distance
        dist_hat = np.linalg.norm(curr_dist)
        dist_rew = 200*(1/dist_hat)
        #dist_rew = 0.
        #angle between landing pad and drone
        temp_angle  = (180/np.pi)* np.arcsin((xyz[2] - self.goal_xyz[2])/dist_hat)[0]
        self.landing_angle = 90 - temp_angle
        att_rew = temp_angle
        roll = zeta[0]*180/np.pi
        pitch = zeta[1]*180/np.pi
        yaw = zeta[2]*180/np.pi

        #print(xyz[0],xyz[1],xyz[2],'GOAL: ',self.goal_xyz[2],dist_hat,'REW: ',dist_rew,att_rew)

        # if((roll < 45 and roll > -45) and (pitch < 45 and pitch > -45)):
        #      ang_rew = 100
        # else:
        #      ang_rew = -(abs(roll)+abs(pitch))[0] ##SHould be negative
        #ang_rew = - (roll-45)**2 * (roll+45)**2        )+abs(pitch))[0]
        ang_rew = (self.get_y(yaw) + self.get_y(roll) + self.get_y(pitch))[0]
        ##print(ang_rew,roll,pitch,yaw)

        vel_rew = 0


        self.dist_norm = dist_hat



        #ang_rew = 0
        #att_rew = 0.
        ctrl_rew = 0#-np.sum(((action/self.action_bound[1])**2))
        time_rew = 1.
        return dist_rew, vel_rew,att_rew, ang_rew, ctrl_rew, time_rew

    def get_y(self,x):
        temp =  (-(x+45)*(x-45))
        return (temp/2025) * 100


    def terminal(self, pos):
        xyz, zeta = pos
        mask1 = 0#zeta > pi/2
        mask2 = 0#zeta < -pi
        mask3 = np.abs(xyz) > 3
        roll = zeta[0]*180/np.pi
        pitch = zeta[1]*180/np.pi
        if np.sum(mask1) > 0 or np.sum(mask2) > 0 or np.sum(mask3) > 0:
            return True
        # elif (xyz[2] - self.goal_xyz[2] < 0 and (np.linalg.norm(xyz - self.goal_xyz)<1.)):  ##Ending it if its less than goal height
        #     return True

        elif(roll > 90 or pitch > 90):
            return True
        elif self.t == self.T:
            print("Sim time reached")
            return True
        else:
            return False

    def step(self, action):
        """

        Parameters
        ----------
        action :

        Returns
        -------
        ob, reward, episode_over, info : tuple
            ob (object) :
                an environment-specific object representing your observation of
                the environment.
            reward (float) :
                amount of reward achieved by the previous action. The scale
                varies between environments, but the goal is always to increase
                your total reward.
            episode_over (bool) :
                whether it's time to reset the environment again. Most (but not
                all) tasks are divided up into well-defined episodes, and done
                being True indicates the episode has terminated. (For example,
                perhaps the pole tipped too far, or you lost your last life.)
            info (dict) :
                 diagnostic information useful for debugging. It can sometimes
                 be useful for learning (for example, it might contain the raw
                 probabilities behind the environment's last state change).
                 However, official evaluations of your agent are not allowed to
                 use this for learning.
        """
        ##Actions can be between trim-bandwidth -> trim+bandwidth

        #temp_rpm = self.trim - (self.bandwidth * (2* action - 1))
        ##print(action)
        for _ in self.steps:
            xyz, zeta, uvw, pqr = self.iris.step(self.trim_np+action*self.bandwidth)

        tmp = zeta.T.tolist()[0]
        sinx = [sin(x) for x in tmp]
        cosx = [cos(x) for x in tmp]
        next_state = xyz.T.tolist()[0]+sinx+cosx+uvw.T.tolist()[0]+pqr.T.tolist()[0]+(action/self.action_bound[1]).tolist()
        info = self.reward((xyz, zeta, uvw, pqr), action)
        done = self.terminal((xyz, zeta))
        reward = sum(info)
        goal = self.vec.T.tolist()[0] + [self.landing_angle]
        self.t += self.ctrl_dt
        next_state = next_state+goal# + [self.landing_angle]
        # print(next_state)
        # print('goal',goal)
        # print('landing',self.landing_angle)
        return next_state, reward, done, info

    def reset(self):

        self.t = 0.
        xyz, zeta, uvw, pqr = self.iris.reset()
        self.goal_xyz = np.array([[random.uniform(-3,3)],
                                [random.uniform(-3,3)],
                                [random.uniform(-3,0)]])

        xyz = np.array([[random.uniform(-3,3)],
                                [random.uniform(-3,3)],
                                [random.uniform(0,3)]])

        self.iris.set_state(xyz, zeta, uvw, pqr)
        self.iris.set_rpm(np.array(self.trim))
        self.vec = xyz-self.goal_xyz
        self.dist_norm = np.linalg.norm(self.vec)
        tmp = zeta.T.tolist()[0]
        action = [x/self.action_bound[1] for x in self.trim]
        sinx = [sin(x) for x in tmp]
        cosx = [cos(x) for x in tmp]

        state = xyz.T.tolist()[0]+sinx+cosx+uvw.T.tolist()[0]+pqr.T.tolist()[0]+action+self.vec.T.tolist()[0] + [self.landing_angle]

        return state



    def render(self, mode='human', close=False):

        if self.fig is None:
            pl.close("all")
            pl.ion()
            self.fig = pl.figure("Flying Skills")
            self.axis3d = self.fig.add_subplot(111, projection='3d')
            self.vis = ani.Visualization(self.iris, 6, quaternion=True)

        pl.figure("Flying Skills")
        self.axis3d.cla()
        cir = pl.Circle((self.goal_xyz[0],self.goal_xyz[1]), 0.5)
        self.axis3d.add_patch(cir)
        art3d.pathpatch_2d_to_3d(cir, z=self.goal_xyz[2], zdir="z")
        self.vis.draw3d_quat(self.axis3d)
        #self.vis.draw_goal(self.axis3d, self.goal)
        self.axis3d.set_xlim(-3, 3)
        self.axis3d.set_ylim(-3, 3)
        self.axis3d.set_zlim(-3, 3)
        self.axis3d.set_xlabel('West/East [m]')
        self.axis3d.set_ylabel('South/North [m]')
        self.axis3d.set_zlabel('Down/Up [m]')
        self.axis3d.set_title("Time %.3f s" %(self.t))
        pl.pause(0.101)
        pl.draw()
